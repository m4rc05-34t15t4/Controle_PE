<div class="rodape">Exército Brasileiro - DCT - DSG - 3ºCGEO - DGEO</div>
<div class="contato-rodape">3º Sgt Marcos Batista +55 (81) 9.9494-1677<br>mbsj2007@hotmail.com</div>
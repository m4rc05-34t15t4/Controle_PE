<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8"/>
        <title>Controle produção</title>
        <meta name="keywords" content="HTML5, CSS3, frontend">
        <meta name="description" content="Controle">
        <meta name="author" content="3º Sgt Topo Marcos Batista">
        <meta http-equiv="Refresh" content="0; url=Todos_mi.php" />
    </head>
    <body>
        
    </body>
</html>